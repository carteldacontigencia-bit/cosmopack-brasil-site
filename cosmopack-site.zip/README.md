# Cosmo Pack Brasil — Site

Site em página única (`index.html`), com todas as imagens já embutidas no
próprio arquivo. Não precisa de build, servidor, ou pasta extra — é só
publicar o `index.html`.

## Subir pro GitHub (primeira vez)

1. Crie um repositório novo em https://github.com/new
   (ex: nome `cosmopack-brasil-site`, pode deixar público ou privado)
2. No terminal, dentro desta pasta:

```bash
git init
git add index.html README.md
git commit -m "Site Cosmo Pack Brasil"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/cosmopack-brasil-site.git
git push -u origin main
```

(troque `SEU_USUARIO` e o nome do repositório pelos seus)

## Conectar no Vercel

1. Acesse https://vercel.com/new
2. Clique em "Import Git Repository" e escolha o repositório que você acabou
   de criar
3. Em "Framework Preset" deixe como **Other** (é HTML puro, sem build)
4. Clique em **Deploy**

Pronto — a partir daí, toda vez que você der `git push` de novo pro `main`,
o Vercel atualiza o site sozinho automaticamente.

## Pra próximas mudanças

Sempre que eu te mandar um `index.html` novo (com ajustes), é só substituir
o arquivo nesta pasta e rodar:

```bash
git add index.html
git commit -m "Atualização do site"
git push
```
